import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

@Test
public void testTaskCreatedSuccessfully() {
Task task = new Task("123", "Homework", "Finish the module four milestone");

assertEquals("123", task.getTaskId());
assertEquals("Homework", task.getName());
assertEquals("Finish the module four milestone", task.getDescription());
}

@Test
public void testTaskIdTooLong() {
assertThrows(IllegalArgumentException.class, () -> {
new Task("12345678901", "Homework", "Finish the module four milestone");
});
}

@Test
public void testTaskIdIsNull() {
assertThrows(IllegalArgumentException.class, () -> {
new Task(null, "Homework", "Finish the module four milestone");
});
}

@Test
public void testNameTooLong() {
assertThrows(IllegalArgumentException.class, () -> {
new Task("123", "ThisNameIsWayTooLongForTask", "Finish the module four milestone");
});
}

@Test
public void testNameIsNull() {
assertThrows(IllegalArgumentException.class, () -> {
new Task("123", null, "Finish the module four milestone");
});
}

@Test
public void testDescriptionTooLong() {
assertThrows(IllegalArgumentException.class, () -> {
new Task("123", "Homework", "This description is definitely going past the fifty character limit allowed");
});
}

@Test
public void testDescriptionIsNull() {
assertThrows(IllegalArgumentException.class, () -> {
new Task("123", "Homework", null);
});
}

@Test
public void testSetNameSuccessfully() {
Task task = new Task("123", "Homework", "Finish the module four milestone");
task.setName("Project");

assertEquals("Project", task.getName());
}

@Test
public void testSetNameTooLong() {
Task task = new Task("123", "Homework", "Finish the module four milestone");

assertThrows(IllegalArgumentException.class, () -> {
task.setName("ThisNameIsWayTooLongForTask");
});
}

@Test
public void testSetNameIsNull() {
Task task = new Task("123", "Homework", "Finish the module four milestone");

assertThrows(IllegalArgumentException.class, () -> {
task.setName(null);
});
}

@Test
public void testSetDescriptionSuccessfully() {
Task task = new Task("123", "Homework", "Finish the module four milestone");
task.setDescription("Work on the test file");

assertEquals("Work on the test file", task.getDescription());
}

@Test
public void testSetDescriptionTooLong() {
Task task = new Task("123", "Homework", "Finish the module four milestone");

assertThrows(IllegalArgumentException.class, () -> {
task.setDescription("This description is definitely going past the fifty character limit allowed");
});
}

@Test
public void testSetDescriptionIsNull() {
Task task = new Task("123", "Homework", "Finish the module four milestone");

assertThrows(IllegalArgumentException.class, () -> {
task.setDescription(null);
});
}
}