import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

@Test
public void testAddTaskSuccessfully() {
TaskService service = new TaskService();
Task task = new Task("1", "Homework", "Finish assignment");

service.addTask(task);

// If no exception happens, it worked
assertTrue(true);
}

@Test
public void testAddDuplicateTaskId() {
TaskService service = new TaskService();
Task task1 = new Task("1", "Homework", "Finish assignment");
Task task2 = new Task("1", "Project", "Work on project");

service.addTask(task1);

assertThrows(IllegalArgumentException.class, () -> {
service.addTask(task2);
});
}

@Test
public void testDeleteTaskSuccessfully() {
TaskService service = new TaskService();
Task task = new Task("1", "Homework", "Finish assignment");

service.addTask(task);
service.deleteTask("1");

// Try deleting again should fail since it's gone now
assertThrows(IllegalArgumentException.class, () -> {
service.deleteTask("1");
});
}

@Test
public void testDeleteTaskNotFound() {
TaskService service = new TaskService();

assertThrows(IllegalArgumentException.class, () -> {
service.deleteTask("999");
});
}

@Test
public void testUpdateNameSuccessfully() {
TaskService service = new TaskService();
Task task = new Task("1", "Homework", "Finish assignment");

service.addTask(task);
service.updateName("1", "Project");

assertEquals("Project", task.getName());
}

@Test
public void testUpdateNameTaskNotFound() {
TaskService service = new TaskService();

assertThrows(IllegalArgumentException.class, () -> {
service.updateName("999", "Project");
});
}

@Test
public void testUpdateDescriptionSuccessfully() {
TaskService service = new TaskService();
Task task = new Task("1", "Homework", "Finish assignment");

service.addTask(task);
service.updateDescription("1", "New description");

assertEquals("New description", task.getDescription());
}

@Test
public void testUpdateDescriptionTaskNotFound() {
TaskService service = new TaskService();

assertThrows(IllegalArgumentException.class, () -> {
service.updateDescription("999", "New description");
});
}
}