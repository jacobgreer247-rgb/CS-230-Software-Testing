import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);
        Appointment appointment = new Appointment("A123", futureDate, "Doctor visit");

        assertEquals("A123", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor visit", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor visit");
        });
    }

    @Test
    public void testAppointmentIdNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor visit");
        });
    }

    @Test
    public void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", null, "Doctor visit");
        });
    }

    @Test
    public void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 1000000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", pastDate, "Doctor visit");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate, "This description is way too long and should not be allowed at all in this class");
        });
    }

    @Test
    public void testDescriptionNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate, null);
        });
    }
}