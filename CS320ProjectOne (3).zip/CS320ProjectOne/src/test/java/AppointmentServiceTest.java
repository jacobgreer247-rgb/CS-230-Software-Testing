import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);
        Appointment appointment = new Appointment("A123", futureDate, "Doctor visit");

        service.addAppointment(appointment);

        assertEquals(appointment, service.getAppointment("A123"));
    }

    @Test
    public void testAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);

        Appointment appointment1 = new Appointment("A123", futureDate, "Doctor visit");
        Appointment appointment2 = new Appointment("A123", futureDate, "Haircut");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000000);
        Appointment appointment = new Appointment("A123", futureDate, "Doctor visit");

        service.addAppointment(appointment);
        service.deleteAppointment("A123");

        assertNull(service.getAppointment("A123"));
    }

    @Test
    public void testDeleteAppointmentThatDoesNotExist() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("A123");
        });
    }
}
