import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    // test adding a contact works
    @Test
    void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        assertEquals("John", service.getContact("123").getFirstName());
    }

    // test duplicate id is not allowed
    @Test
    void testAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        Contact contact2 = new Contact("123", "Mike", "Smith", "0987654321", "456 Road");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    // test deleting a contact works
    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.deleteContact("123");
        assertNull(service.getContact("123"));
    }

    // test updating first name works
    @Test
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.updateFirstName("123", "Mike");
        assertEquals("Mike", service.getContact("123").getFirstName());
    }

    // test updating last name works
    @Test
    void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.updateLastName("123", "Smith");
        assertEquals("Smith", service.getContact("123").getLastName());
    }

    // test updating phone works
    @Test
    void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.updatePhone("123", "0987654321");
        assertEquals("0987654321", service.getContact("123").getPhone());
    }

    // test updating address works
    @Test
    void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.updateAddress("123", "456 New Road");
        assertEquals("456 New Road", service.getContact("123").getAddress());
    }
}

