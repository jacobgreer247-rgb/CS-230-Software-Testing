import java.util.ArrayList;

public class TaskService {
   
    private ArrayList<Task> tasks = new ArrayList<Task>();
   
    public void addTask(Task task) {
        // Make sure the task is not null
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
       
        // Check for duplicate task IDs
        for (Task existingTask : tasks) {
            if (existingTask.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID must be unique");
            }
        }
       
        tasks.add(task);
    }
   
    public void deleteTask(String taskId) {
        // Look for the task with the matching ID and remove it
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                tasks.remove(i);
                return;
            }
        }
       
        throw new IllegalArgumentException("Task ID was not found");
    }
   
    public void updateName(String taskId, String name) {
        // Find the right task and update the name
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setName(name);
                return;
            }
        }
       
        throw new IllegalArgumentException("Task ID was not found");
    }
   
    public void updateDescription(String taskId, String description) {
        // Find the right task and update the description
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setDescription(description);
                return;
            }
        }
       
        throw new IllegalArgumentException("Task ID was not found");
    }
}