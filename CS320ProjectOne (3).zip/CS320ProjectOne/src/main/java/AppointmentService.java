import java.util.ArrayList;

public class AppointmentService {

    // this just holds all appointments in memory
    private ArrayList<Appointment> appointments = new ArrayList<>();

    // add a new appointment, but make sure ID is unique
    public void addAppointment(Appointment appointment) {
        for (Appointment a : appointments) {
            if (a.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("ID already exists");
            }
        }
        appointments.add(appointment);
    }

    // delete an appointment using its ID
    public void deleteAppointment(String appointmentId) {
        for (int i = 0; i < appointments.size(); i++) {
            if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
                appointments.remove(i);
                return;
            }
        }
        throw new IllegalArgumentException("Appointment not found");
    }

    // helper method just to check if something exists (helps with testing)
    public Appointment getAppointment(String appointmentId) {
        for (Appointment a : appointments) {
            if (a.getAppointmentId().equals(appointmentId)) {
                return a;
            }
        }
        return null;
    }
}