public class Task {
   
    private final String taskId;
    private String name;
    private String description;
   
    public Task(String taskId, String name, String description) {
        // Make sure task ID is valid before saving it
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID is not valid");
        }
       
        // Make sure name is valid
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name is not valid");
        }
       
        // Make sure description is valid
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is not valid");
        }
       
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }
   
    public String getTaskId() {
        return taskId;
    }
   
    public String getName() {
        return name;
    }
   
    public String getDescription() {
        return description;
    }
   
    public void setName(String name) {
        // Check that the new name follows the rules
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name is not valid");
        }
       
        this.name = name;
    }
   
    public void setDescription(String description) {
        // Check that the new description follows the rules
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is not valid");
        }
       
        this.description = description;
    }
}